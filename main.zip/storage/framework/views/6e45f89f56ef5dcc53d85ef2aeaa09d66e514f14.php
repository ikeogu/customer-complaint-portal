<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
      <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Complaints</h1>


                    </div>

                    <!-- Content Row -->
                    <div class="row">





                    <!-- DataTales Example -->
                    <div class="card shadow ">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Complaints table</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>

                                        <tr>
                                            <th>Title</th>
                                            <th>Message</th>
                                            <th>Made By</th>
                                            <th>Branch</th>
                                            <th>Reviewed</th>
                                            <th>sent</th>
                                            <th>Action</th>

                                        </tr>
                                    </thead>

                                    <tbody>


                                            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                             <td><?php echo e($item->title); ?></td>
                                            <td><?php echo e($item->message); ?></td>
                                            <td>
                                               <?php echo e($item->customers->user->first_name); ?>  <?php echo e($item->customers->user->last_name); ?>

                                            </td>
                                             <td>
                                               <?php echo e($item->customers->branch->name); ?>

                                            </td>
                                             <td>
                                               <?php if($item->reviewed == 1): ?>
                                                Reviewed
                                               <?php else: ?>
                                                Not Reviewed
                                               <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->created_at->diffForHumans()); ?></td>
                                            <td>
                                                <a  class="btn btn-primary" href="<?php echo e(route('RW',[$item->id])); ?>">
                                                 Review

                                                </a>
                                                    <form method="post" action="<?php echo e(route('complaint.destroy',[$item->id])); ?>" >
                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <?php echo e(csrf_field()); ?>

                                                    <button type="submit" class="btn btn-danger btn-sm"><?php echo e(trans('Delete')); ?></button>
                                                    </form>


                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                                <?php echo e($complaints->links()); ?>

                            </div>
                        </div>
                    </div>
                    </div>

                    <!-- Content Row -->


                </div>
                <!-- /.container-fluid -->
               <!-- Button trigger modal -->


 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /home/chiboy/lampstack-8.0.5-0/apache2/htdocs/customer-complain-portal/resources/views/admin/complaints.blade.php ENDPATH**/ ?>
<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH /home/chiboy/lampstack-8.0.5-0/apache2/htdocs/customer-complain-portal/resources/views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>